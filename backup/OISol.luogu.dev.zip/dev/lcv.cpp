#include "luogu.hpp"

int main()
{
    LG_SYS("cat /proc/version");
    // Expected result:
    // Linux version 4.9.116-43.59.amzn1.x86_64 (mockbuild@gobi-build-64012) (gcc version 7.2.1 20170915 (Red Hat 7.2.1-2) (GCC) ) #1 SMP Thu Aug 2 23:15:06 UTC 2018
}
